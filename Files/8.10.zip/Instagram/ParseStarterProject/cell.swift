//
//  cell.swift
//  ParseStarterProject
//
//  Created by Rob Percival on 19/05/2015.
//  Copyright (c) 2015 Parse. All rights reserved.
//

import UIKit

class cell: UITableViewCell {
    
    @IBOutlet var postedImage: UIImageView!
    
    @IBOutlet var username: UILabel!
    
    @IBOutlet var message: UILabel!
    
}
