

//: Playground - noun: a place where people can play

// While Looping Through An Array

var myArray = [8, 3, 6, 8, 2, 45, 21]

var i = 0

while i < myArray.count {
    
    myArray[i] = myArray[i] - 1
    
    i++
    
}

print(myArray)



// Basic While Loop

i = 1

while i <= 10 {
    
    print(i * 5)
    
    i++
    
}











