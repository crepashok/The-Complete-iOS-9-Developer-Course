//: Playground - noun: a place where people can play

import UIKit

// Strings

var str = "Hello, playground"

var name = "Rob"

print("hello " + name + ".")

// Integers (whole numbers)

var int:Int = 9

int = int * 2

int = int / 4

var anotherInt = 7

print(int + anotherInt)

print("The value of int is \(int)")

// Doubles (numbers with decimals)

var number:Double = 8.4

print(number * Double(int))

// Booleans (true or false)

var isMale:Bool = true

// Challenge Solution

var a:Double = 5.76

var b:Int = 8

print("The product of \(a) and \(b) is \(a * Double(b))")